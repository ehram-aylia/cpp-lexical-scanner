 #include <iostream>
 #include <fstream>
 #include <sstream>
 #include <regex>
 #include <vector>
 using namespace std;
 int main() {
 ifstream input("input.txt");
 ofstream output("output.txt");
 if (!input) {
 cerr << "Error: Could not open input file!\n";
 return 1;
    }
 stringstream buffer;
    buffer << input.rdbuf();
 string code = buffer.str();
    code = regex_replace(code, regex("\\s+"), " ");
 vector<string> tokens;
 regex tokenPattern(R"([a-zA-Z_][a-zA-Z0-9_]*|\d+|==|!=|<=|>=|[+\-*/=;{}()<>])");
 sregex_iterator begin(code.begin(), code.end(), tokenPattern);
 sregex_iterator end;
    output << "Tokens found:\n";
 for (auto it = begin; it != end; ++it) {
        tokens.push_back(it->str());
        output << it->str() << "\n";
    }
 cout << "Processing complete! Tokens saved in 'input.txt'.\n";
    input.close();
    output.close();
 return 0;
 }
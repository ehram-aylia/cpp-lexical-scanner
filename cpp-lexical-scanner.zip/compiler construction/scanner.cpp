// scanner.cpp
// Simple lexical scanner using two-pointer input buffering style.
// Produces tokens and collects lexical errors into tokens.txt
// Compile: g++ -std=c++17 scanner.cpp -o scanner

#include <bits/stdc++.h>
using namespace std;

struct Token {
    string type;
    string lexeme;
    int line;
};

string inputBuffer;                // holds entire file content
vector<Token> tokens;              // collected tokens
vector<string> errorBuffer;        // collected errors
int lineNumber = 1;                // current line while scanning

// --- Utility sets ------------------------------------------------
const unordered_set<string> keywords = {
    "auto","break","case","char","const","continue","default","do","double",
    "else","enum","extern","float","for","goto","if","inline","int","long",
    "register","restrict","return","short","signed","sizeof","static","struct",
    "switch","typedef","union","unsigned","void","volatile","while","class",
    "public","private","protected","namespace","using","bool","true","false",
    "nullptr","new","delete","try","catch","throw"
};

const unordered_set<char> singleCharSeparators = {
    '(',')','{','}','[',']',',',';',':','.'
};

// We'll recognize these single char operators and allow multi-char combos via logic.
const unordered_set<char> operatorChars = {
    '+','-','*','/','%','<','>','=','!','&','|','^','~','?'
};

// --- Function declarations ---------------------------------------
void ReadFile(const string &filename);
void scanTokens();
void writeFile(const string &outFilename = "tokens.txt");

// Helper recognizers:
bool isIdentifierStart(char c) { return isalpha((unsigned char)c) || c == '_'; }
bool isIdentifierPart(char c)  { return isalnum((unsigned char)c) || c == '_'; }
bool isDigit(char c)           { return isdigit((unsigned char)c); }

// --- Implementations ---------------------------------------------
void ReadFile(const string &filename) {
    // Read whole file into inputBuffer (simple buffered read)
    ifstream in(filename, ios::in | ios::binary);
    if (!in) {
        cerr << "Error: Cannot open input file: " << filename << "\n";
        exit(1);
    }
    std::ostringstream ss;
    ss << in.rdbuf();
    inputBuffer = ss.str();
    // Ensure there's a sentinel to avoid out-of-bound checks (optional)
    inputBuffer.push_back('\0'); // sentinel zero char (not part of file)
    lineNumber = 1;
}

// scanTokens implements lexemeBegin-forward scanning
void scanTokens() {
    tokens.clear();
    errorBuffer.clear();
    int n = (int)inputBuffer.size();
    int lexemeBegin = 0;
    int forward = 0;

    auto addToken = [&](const string &type, const string &lex) {
        tokens.push_back({type, lex, lineNumber});
    };

    // increment lineNumber appropriately when advancing over newlines.
    auto advanceAndCount = [&](int &idx) {
        if (idx < n && inputBuffer[idx] == '\n') lineNumber++;
        idx++;
    };

    while (lexemeBegin < n && inputBuffer[lexemeBegin] != '\0') {
        // skip whitespace
        while (lexemeBegin < n) {
            char c = inputBuffer[lexemeBegin];
            if (c == '\0') break;
            if (isspace((unsigned char)c)) {
                if (c == '\n') lineNumber++;
                lexemeBegin++;
            } else break;
        }
        if (lexemeBegin >= n || inputBuffer[lexemeBegin] == '\0') break;

        forward = lexemeBegin;
        char c = inputBuffer[forward];

        // 1) Identifier / Keyword
        if (isIdentifierStart(c)) {
            string lex;
            while (forward < n && isIdentifierPart(inputBuffer[forward])) {
                lex.push_back(inputBuffer[forward]);
                forward++;
            }
            // token recognized
            if (keywords.count(lex)) addToken("KEYWORD", lex);
            else addToken("IDENTIFIER", lex);
            lexemeBegin = forward;
            continue;
        }

        // 2) Number: integer or floating point
        if (isDigit(c)) {
            string lex;
            bool isFloat = false;
            // integer part
            while (forward < n && isDigit(inputBuffer[forward])) {
                lex.push_back(inputBuffer[forward]);
                forward++;
            }
            // fractional part
            if (forward < n && inputBuffer[forward] == '.') {
                // check next char to be digit for a valid float
                if (forward + 1 < n && isDigit(inputBuffer[forward + 1])) {
                    isFloat = true;
                    lex.push_back('.');
                    forward++;
                    while (forward < n && isDigit(inputBuffer[forward])) {
                        lex.push_back(inputBuffer[forward]);
                        forward++;
                    }
                } else {
                    // It's something like '123.' maybe accept as float with no fraction? we'll accept
                    isFloat = true;
                    lex.push_back('.');
                    forward++;
                }
            }
            // exponent part (optional)
            if (forward < n && (inputBuffer[forward] == 'e' || inputBuffer[forward] == 'E')) {
                int save = forward;
                string expo;
                expo.push_back(inputBuffer[forward]);
                forward++;
                if (forward < n && (inputBuffer[forward] == '+' || inputBuffer[forward] == '-')) {
                    expo.push_back(inputBuffer[forward]);
                    forward++;
                }
                bool hasDigits = false;
                while (forward < n && isDigit(inputBuffer[forward])) {
                    expo.push_back(inputBuffer[forward]);
                    forward++;
                    hasDigits = true;
                }
                if (hasDigits) {
                    isFloat = true;
                    lex += expo;
                } else {
                    // not a valid exponent; rollback to previous position (treat 'e' as separate?)
                    forward = save; // do not take exponent
                }
            }
            addToken(isFloat ? "FLOAT_CONST" : "INT_CONST", lex);
            lexemeBegin = forward;
            continue;
        }

        // 3) String literal (double quotes)
        if (c == '"') {
            string lex;
            lex.push_back(c);
            forward++;
            bool closed = false;
            while (forward < n && inputBuffer[forward] != '\0') {
                char ch = inputBuffer[forward];
                lex.push_back(ch);
                if (ch == '\\') {
                    // escape next char if present
                    if (forward + 1 < n) {
                        forward++;
                        lex.push_back(inputBuffer[forward]);
                    }
                } else if (ch == '"') {
                    closed = true;
                    forward++;
                    break;
                } else {
                    if (ch == '\n') lineNumber++; // string contains newline
                }
                forward++;
            }
            if (!closed) {
                errorBuffer.push_back(string("Unterminated string literal at line ") + to_string(lineNumber));
            } else {
                addToken("STRING_LITERAL", lex);
            }
            lexemeBegin = forward;
            continue;
        }

        // 4) Comments or division operator
        if (c == '/') {
            if (forward + 1 < n && inputBuffer[forward + 1] == '/') {
                // single-line comment: consume until end of line
                string lex;
                lex.push_back('/');
                lex.push_back('/');
                forward += 2;
                while (forward < n && inputBuffer[forward] != '\n' && inputBuffer[forward] != '\0') {
                    lex.push_back(inputBuffer[forward]);
                    forward++;
                }
                // Option: record comment or ignore. We'll ignore but could store as token.
                // addToken("COMMENT_LINE", lex);
                lexemeBegin = forward;
                continue;
            } else if (forward + 1 < n && inputBuffer[forward + 1] == '*') {
                // multi-line comment: consume until */
                string lex;
                lex.push_back('/');
                lex.push_back('*');
                forward += 2;
                bool closed = false;
                while (forward + 1 < n) {
                    if (inputBuffer[forward] == '*' && inputBuffer[forward + 1] == '/') {
                        lex.push_back('*');
                        lex.push_back('/');
                        forward += 2;
                        closed = true;
                        break;
                    } else {
                        if (inputBuffer[forward] == '\n') lineNumber++;
                        lex.push_back(inputBuffer[forward]);
                        forward++;
                    }
                }
                if (!closed) {
                    errorBuffer.push_back(string("Unterminated comment starting at line ") + to_string(lineNumber));
                } else {
                    // addToken("COMMENT_BLOCK", lex);
                }
                lexemeBegin = forward;
                continue;
            }
            // else fall through as operator '/'
        }

        // 5) Operators and multi-char operators
        if (operatorChars.count(c)) {
            string lex;
            lex.push_back(c);
            // try to detect common multi-character operators:
            char next = (forward + 1 < n) ? inputBuffer[forward + 1] : '\0';

            // Common two-char combos
            string two;
            two.push_back(c);
            two.push_back(next);

            const unordered_set<string> twoCharOps = {
                "++","--","+=","-=","*=","/=","%=","==","!=","<=",">=","<<",">>","&&","||","->","<<=",">>=",
                "&=","|=","^=","::","?:"
            };

            if (twoCharOps.count(two)) {
                lex.push_back(next);
                forward += 2;
            } else {
                // treat '=' following certain chars: e.g., '>' and '=' already handled, otherwise single char operator
                forward += 1;
            }
            addToken("OPERATOR", lex);
            lexemeBegin = forward;
            continue;
        }

        // 6) Separators/punctuators (single char)
        if (singleCharSeparators.count(c)) {
            string lex(1, c);
            addToken("SEPARATOR", lex);
            if (c == '\n') lineNumber++;
            lexemeBegin = forward + 1;
            continue;
        }

        // 7) Other whitespace / newlines handled earlier. If it's an unknown char -> error
        {
            string unknown(1, c);
            errorBuffer.push_back(string("Unrecognized symbol '") + unknown + "' at line " + to_string(lineNumber));
            // advance 1 position
            if (c == '\n') lineNumber++;
            lexemeBegin = forward + 1;
            continue;
        }
    } // end while

    // End of scanning
}

// write tokens and errors to file
void writeFile(const string &outFilename) {
    ofstream out(outFilename);
    if (!out) {
        cerr << "Error: Cannot open output file: " << outFilename << "\n";
        return;
    }

    out << "TOKENS\n";
    out << "------\n";
    for (const auto &t : tokens) {
        out << t.type << " : " << t.lexeme << " (line " << t.line << ")\n";
    }
    out << "\nERRORS\n";
    out << "------\n";
    if (errorBuffer.empty()) {
        out << "No lexical errors found.\n";
    } else {
        for (const string &e : errorBuffer) {
            out << e << "\n";
        }
    }
    out.close();
    cout << "Wrote tokens and errors to " << outFilename << "\n";
}

// --- main for demonstration / testing -----------------------------
int main(int argc, char** argv) {
    if (argc < 2) {
        cerr << "Usage: " << argv[0] << " <input-source-file>\n";
        return 1;
    }
    string infile = argv[1];
    ReadFile(infile);
    scanTokens();
    writeFile("tokens.txt");
    return 0;
}
